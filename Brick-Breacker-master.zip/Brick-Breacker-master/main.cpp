#include "game.h"


int main()
{
	// I hope You Enjoyy <33
	//Create an object of controller
	game Game;

	Game.go();


	
	return 0;
}

